CREATE VIEW vw_Detacomen AS 
SELECT
	v.*,
    c.comentario
FROM
	plataformastreamingjogos.vw_detalhetransmissoes as v
INNER JOIN 
	transmissoes AS t ON t.data_transmissao = v.data_transmissao
INNER JOIN 
	comentarios as c ON c.transmissao_id = t.id;
